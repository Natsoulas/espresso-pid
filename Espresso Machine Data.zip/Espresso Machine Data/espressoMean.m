function [totAvg, totCov] = espressoMean(averageArray)

totAvg = mean(averageArray);
totCov = var(averageArray);